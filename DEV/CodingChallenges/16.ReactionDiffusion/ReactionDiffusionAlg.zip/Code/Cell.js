
function Cell() {
  this.a = 1;
  this.b = 0;
}
